<?php
if ( et_theme_builder_overrides_layout( ET_THEME_BUILDER_HEADER_LAYOUT_POST_TYPE ) || et_theme_builder_overrides_layout( ET_THEME_BUILDER_FOOTER_LAYOUT_POST_TYPE ) ) {
    // Skip rendering anything as this partial is being buffered anyway.
    // In addition, avoids get_sidebar() issues since that uses
    // locate_template() with require_once.
    return;
}

/**
 * Fires after the main content, before the footer is output.
 *
 * @since 3.10
 */
do_action( 'et_after_main_content' );

if ( 'on' === et_get_option( 'divi_back_to_top', 'false' ) ) : ?>

	<span class="et_pb_scroll_top et-pb-icon"></span>

<?php endif;

if ( ! is_page_template( 'page-template-blank.php' ) ) : ?>

			<footer id="main-footer">
				<?php get_sidebar( 'footer' ); ?>


		<?php
			if ( has_nav_menu( 'footer-menu' ) ) : ?>

				<div id="et-footer-nav">
					<div class="container">
						<?php
							wp_nav_menu( array(
								'theme_location' => 'footer-menu',
								'depth'          => '1',
								'menu_class'     => 'bottom-nav',
								'container'      => '',
								'fallback_cb'    => '',
							) );
						?>
					</div>
				</div> <!-- #et-footer-nav -->

			<?php endif; ?>

				<div id="footer-bottom">
					<div class="container clearfix">
				<?php
					if ( false !== et_get_option( 'show_footer_social_icons', true ) ) {
						get_template_part( 'includes/social_icons', 'footer' );
					}

					// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped
					echo et_core_fix_unclosed_html_tags( et_core_esc_previously( et_get_footer_credits() ) );
					// phpcs:enable
				?>
					</div>	<!-- .container -->
				</div>
			</footer> <!-- #main-footer -->
		</div> <!-- #et-main-area -->

<?php endif; // ! is_page_template( 'page-template-blank.php' ) ?>

	</div> <!-- #page-container -->

	<?php wp_footer(); ?>
	
	
	<style>
.exitLightbox {
    display: none;
    position: fixed;
    z-index: 111111;
    width: 100%;
    height: 100%;
    overflow-y: auto;
    top: 0;
    left: 0;
    background-color: rgba(0, 0, 0, 0.5);
}
.logged-in .exitLightbox{display: none!important;}
.exitLightbox__closer{
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
}
.exitLightbox__inner {
  position: absolute;
  padding: 10px;
  top: 0;
  left: 50%;
  transform: translate(-50%, 0);
  background: #fff;
	width:1080px;
	max-width:100%;
}
.exitLightbox__close {
	position: absolute;
	right: 5px;
	top: 5px;
	margin: 0px 0 0 0;
	width: 50px;
	height: 50px;
	font-size: 45px;
	font-weight: bold;
	text-align: center;
	border-radius: 50%;
	cursor: pointer;
	text-decoration: none;
	border: 1px solid;
	z-index: 1111;
	padding-top: 11px;
	color: #000;
}
.exitLightbox .tools-top-ad-wrapper h2 {
  line-height: 1;
  padding-top: 5px;
  text-align: left;
  font-size: 26px;
  margin-top: 0;
}
.exitLightbox__img{
  max-width: 100%;
  height: auto;
  float: left;
  width: 90px;
  border: 1px solid #cecece;
  border-radius: 50%;
  margin-right: 10px;
  margin-bottom: 10px;
}
</style>
<aside class="exitLightbox">
	<div class="exitLightbox__closer"></div>
      <div class="exitLightbox__inner">
          <a href="javascript:;" class="exitLightbox__close">&times;</a>
          <div class="tooladsaside">
            <div class="tools-top-ad-wrapper">
							<img class="exitLightbox__img" src="https://webdevpuneet.com/wp-content/uploads/2021/06/logo4.png">
              <h2>Top Online Web Development Tools (Free)</h2>
				<p><b>Check out and bookmark</b> these online tools, popular among web developers for interactive-learning, creativity, and better productivity at work. Please ignore if you are already using them. Thank you <img draggable="false" role="img" class="emoji" alt="🙂" src="https://s.w.org/images/core/emoji/13.0.1/svg/1f642.svg"></p>
            	<div class="tools-top-ad">
                <a target="_blank" href="https://tools.webdevpuneet.com/image-compressor/">
            			<img style="padding:10px;" src="https://tools.webdevpuneet.com/image-compressor/image-compression-180.png" alt="Image Resizer & Compressor">
            			<h4 class="card-title">Image Resizer & Compressor</h4>
            		</a>
            		<a target="_blank" href="https://tools.webdevpuneet.com/color-picker/">
            			<img style="padding:10px;" src="https://tools.webdevpuneet.com/color-picker/color-picker-180.png" alt="Color Picker">
            			<h4 class="card-title">Color Picker</h4>
            		</a>
            		<a target="_blank" href="https://tools.webdevpuneet.com/difference-checker/">
            			<img style="padding:10px;" src="https://tools.webdevpuneet.com/difference-checker/difference-checker-180.png" alt="Difference Checker">
            			<h4 class="card-title">Difference Checker</h4>
            		</a>
            		<a target="_blank" href="https://tools.webdevpuneet.com/css-clip-path-generator/">
            			<img style="padding:10px;" src="https://tools.webdevpuneet.com/css-clip-path-generator/css-clip-path-generator-180.png" class="card-img-top" alt="CSS Clip Path Generator">
            			<h4 class="card-title">CSS Clip Path Generator</h4>
            		</a>
            		<a target="_blank" href="https://tools.webdevpuneet.com/css-box-shadow-generator/">
            			<img src="https://tools.webdevpuneet.com/css-box-shadow-generator/box-shadow-180.png" class="card-img-top" alt="CSS Box Shadow Generator">
            			<h4 class="card-title">CSS Box Shadow Generator</h4>
            		</a>
            		<a target="_blank" href="https://tools.webdevpuneet.com/css-text-shadow-generator/">
            			<img src="https://tools.webdevpuneet.com/css-text-shadow-generator/text-shadow-180.png" class="card-img-top" alt="CSS Text Shadow Generator">
            			<h4 class="card-title">CSS Text Shadow Generator</h4>
            		</a>
            		<a target="_blank" href="https://tools.webdevpuneet.com/css-gradient-generator/">
            			<img src="https://tools.webdevpuneet.com/css-gradient-generator/gradient-180.png" class="card-img-top" alt="CSS Gradient Generator">
            			<h4 class="card-title">CSS Gradient Generator</h4>
            		</a>
            		<a target="_blank" href="https://tools.webdevpuneet.com/css-animated-gradient-generator/">
            			<img src="https://tools.webdevpuneet.com/css-animated-gradient-generator/animated-gradient-180.png" class="card-img-top" alt="CSS Animated Gradient Background Generator">
            			<h4 class="card-title">CSS Animated Gradient Generator</h4>
            		</a>
            		<a target="_blank" href="https://tools.webdevpuneet.com/css-easing-generator/">
            			<img style="padding:10px;" src="https://tools.webdevpuneet.com/css-easing-generator/easing-180.png" alt="CSS Easing / Cubic-Bezier Generator">
            			<h4 class="card-title">CSS Easing / Cubic-Bezier Generator</h4>
            		</a>
            		<a target="_blank" href="https://tools.webdevpuneet.com/image-to-base64-converter/">
            			<img style="padding:15px;" src="https://tools.webdevpuneet.com/image-to-base64-converter/image-to-base64-180.png" alt="Image to Base64 Converter">
            			<h4 class="card-title">Image to Base64 Converter</h4>
            		</a>
            		<a target="_blank" href="https://tools.webdevpuneet.com/css-autoprefixer/">
            			<img style="padding:10px;" src="https://tools.webdevpuneet.com/css-autoprefixer/css-autoprefixer-180.png" class="card-img-top" alt="CSS Autoprefixer">
            			<h4 class="card-title">CSS Autoprefixer</h4>
            		</a>
            		<a target="_blank" href="https://tools.webdevpuneet.com/html-css-js-minifier/">
            			<img style="padding:10px;" src="https://tools.webdevpuneet.com/html-css-js-minifier/minifier-180.png" alt="HTML, CSS, JS Minifier">
            			<h4 class="card-title">HTML, CSS, JS Minifier</h4>
            		</a>
            		<a target="_blank" href="https://tools.webdevpuneet.com/js-minify-and-uglify/">
            			<img style="padding:10px;" src="https://tools.webdevpuneet.com/js-minify-and-uglify/uglify-js-180.png" alt="JavaScript Minify and Uglify">
            			<h4 class="card-title">JavaScript Minify and Uglify</h4>
            		</a>
            		<a target="_blank" href="https://tools.webdevpuneet.com/beautifier/html/">
            			<img style="padding:10px;" src="https://tools.webdevpuneet.com/beautifier/beautifier-180.png" alt="HTML, CSS, JS Beautifiers">
            			<h4 class="card-title">HTML, CSS, JS Beautifiers</h4>
            		</a>
            	</div>
            </div>
          </div>
      </div><!-- /.exitLightbox__inner -->
    </aside><!-- /.exitLightbox -->

<script>
(function($) {
$(document).ready(function() {
	if ( $(window).width() > 991) {
    	function addEvent(obj, evt, fn) {
    		if (obj.addEventListener) {
    			obj.addEventListener(evt, fn, false);
    		} else if (obj.attachEvent) {
    			obj.attachEvent("on" + evt, fn);
    		}
    	}

      addEvent(document, 'mouseout', function(evt) {
          if (evt.toElement == null && evt.relatedTarget == null) {
              $('.exitLightbox').show();
          };
      });

      $('a.exitLightbox__close, .exitLightbox__closer').click(function() {
          $('.exitLightbox').hide();
      });
	}
})
})(jQuery);
</script>

</body>
</html>
